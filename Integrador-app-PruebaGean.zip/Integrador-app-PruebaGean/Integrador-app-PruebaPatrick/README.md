## Elaboración de aplicación web para cotización y control de inventario de la empresa JKM Confecciones
### Autores
- Aguirre Calcina Gianfranco Stiven 
- Apaza Achata Andrehe Epifanio
- Calderon Huamantupa Patrick Anthony
- Coa Palo Jhadira Jazmin
- Quispesivana Huamani Fidel 
- Quiñones Sencca Abelardo Gregory 
- Salas Salazar Miguel Ángel 
- Saldivar Saldivar Erick
- Vilca Salazar Geanfranco
- Vilcazan Sillo Antony Pedro 
