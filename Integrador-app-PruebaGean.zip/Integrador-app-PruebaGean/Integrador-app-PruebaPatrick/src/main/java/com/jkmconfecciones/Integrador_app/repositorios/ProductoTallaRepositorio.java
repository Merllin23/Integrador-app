package com.jkmconfecciones.Integrador_app.repositorios;

import com.jkmconfecciones.Integrador_app.entidades.ProductoTalla;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoTallaRepositorio extends JpaRepository<ProductoTalla, Long> { }
